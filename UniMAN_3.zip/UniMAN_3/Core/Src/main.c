/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "math.h"


/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct {
    float x;
    float y;
} Vec2;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define SERVO_COUNT 4
#define MAX_JOINTS 3
#define FABRIK_ITERATIONS 360
#define FABRIK_EPSILON 0.01f
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
volatile uint8_t emergency_stop = 0;
volatile uint32_t last_button_time = 0;

uint8_t servo_angle[SERVO_COUNT] = {0, 0, 0, 0};
uint32_t servo_channel[SERVO_COUNT] = {
    TIM_CHANNEL_2,
    TIM_CHANNEL_3,
    TIM_CHANNEL_4,
	TIM_CHANNEL_1
};
uint32_t servo_pulse_min[SERVO_COUNT] = {
    575,
    575,
    390,
	875,
};
uint32_t servo_pulse_max[SERVO_COUNT] = {
    2525,
    2525,
    2370,
	2525,
};

Vec2 joints[MAX_JOINTS];
float lengths[MAX_JOINTS - 1];
int joint_count = MAX_JOINTS;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */
void set_servo_angle(uint8_t servo_id, uint8_t angle){
  uint16_t pulse_min=servo_pulse_min[servo_id];  // 1 ms = 1000
  uint16_t pulse_max=servo_pulse_max[servo_id];  // 2 ms = 2000

  if (servo_id >= SERVO_COUNT) return;
  if(servo_id==1) angle=180-angle;

  uint16_t pulse=pulse_min+((pulse_max-pulse_min)*angle)/180;

  __HAL_TIM_SET_COMPARE(&htim2, servo_channel[servo_id], pulse);
      servo_angle[servo_id] = angle;
}

void set_servo_angle_smooth(uint8_t servo_id, uint8_t angle)
{
    if (servo_id >= SERVO_COUNT || emergency_stop) return;

    uint16_t pulse_min=servo_pulse_min[servo_id];
    uint16_t pulse_max=servo_pulse_max[servo_id];

    if(servo_id==1) angle=180-angle;

    uint16_t pulse_now=__HAL_TIM_GET_COMPARE(&htim2, servo_channel[servo_id]);

    if (!pulse_now) pulse_now=pulse_min+((pulse_max-pulse_min)*servo_angle[servo_id])/180;
    uint16_t pulse_target=pulse_min+((pulse_max-pulse_min)*angle)/180;

    int step=(pulse_target>pulse_now)?1:-1;

    for (int p=pulse_now; p!=pulse_target; p+=step){
        if (emergency_stop) return;

        __HAL_TIM_SET_COMPARE(&htim2, servo_channel[servo_id], p);
        servo_angle[servo_id]=((p-pulse_min)*180)/(pulse_max-pulse_min);

        HAL_Delay(2);   // MG995 lubi wolniejsze ruchy
    }

    servo_angle[servo_id]=angle;
    if(servo_id==1) servo_angle[servo_id]=180-angle;
}


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
    if(GPIO_Pin==GPIO_PIN_13){
        uint32_t now=HAL_GetTick();

        // Debounce ~200 ms
        if(now-last_button_time<200) return;
        last_button_time=now;

        // TOGGLE
        emergency_stop ^= 1;

        if(emergency_stop){
            // STOP – natychmiast wyłącz PWM
        	for (int i = 0; i < SERVO_COUNT; i++) __HAL_TIM_SET_COMPARE(&htim2, servo_channel[i], 0);
        }
        else{
            // RUN – wróć do ostatniej pozycji
        	for (int i = 0; i < SERVO_COUNT; i++) set_servo_angle(i, servo_angle[i]);
        }
    }
}



int _write(int file, char *ptr, int len){
	int i;
	for(i=0; i<len; i++){
		ITM_SendChar(*ptr++);
	}
	return len;
}

float vec_dist(Vec2 a, Vec2 b)
{
    float dx = b.x - a.x;
    float dy = b.y - a.y;
    return sqrtf(dx*dx + dy*dy);
}

Vec2 vec_add(Vec2 a, Vec2 b)
{
    return (Vec2){ a.x + b.x, a.y + b.y };
}

Vec2 vec_sub(Vec2 a, Vec2 b)
{
    return (Vec2){ a.x - b.x, a.y - b.y };
}

Vec2 vec_scale(Vec2 v, float s)
{
    return (Vec2){ v.x * s, v.y * s };
}

Vec2 vec_normalize(Vec2 v)
{
    float len = sqrtf(v.x*v.x + v.y*v.y);
    if (len < 1e-6f) return (Vec2){0,0};
    return vec_scale(v, 1.0f / len);
}

void fabrik_solve(Vec2 target)
{
    float total_length = 0.0f;
    for (int i = 0; i < joint_count - 1; i++)
        total_length += lengths[i];

    Vec2 base = joints[0];
    float dist_to_target = vec_dist(base, target);

    //CEL NIEOSIĄGALNY
    if (dist_to_target > total_length)
    {
        for (int i = 0; i < joint_count - 1; i++)
        {
            Vec2 dir = vec_normalize(vec_sub(target, joints[i]));
            joints[i+1] = vec_add(joints[i], vec_scale(dir, lengths[i]));
        }
        return;
    }

    //CEL OSIĄGALNY
    for (int iter = 0; iter < FABRIK_ITERATIONS; iter++)
    {
        // --- FORWARD ---
        joints[joint_count - 1] = target;

        for (int i = joint_count - 2; i >= 0; i--)
        {
            Vec2 dir = vec_normalize(vec_sub(joints[i], joints[i+1]));
            joints[i] = vec_add(joints[i+1], vec_scale(dir, lengths[i]));
        }

        // --- BACKWARD ---
        joints[0] = base;

        for (int i = 0; i < joint_count - 1; i++)
        {
            Vec2 dir = vec_normalize(vec_sub(joints[i+1], joints[i]));
            joints[i+1] = vec_add(joints[i], vec_scale(dir, lengths[i]));
        }

        // --- STOP ---
        if (vec_dist(joints[joint_count - 1], target) < FABRIK_EPSILON)
            break;
    }
}

float compute_angle(Vec2 from, Vec2 to)
{
    return atan2f(to.y - from.y, to.x - from.x) * 180.0f / M_PI;
}

void close_efektor(){
	set_servo_angle_smooth(3, 90);
}
void open_efektor(){
	set_servo_angle_smooth(3, 0);
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  joints[0] = (Vec2){0.0f, 0.0f};
  joints[1] = (Vec2){1.0f, 0.0f};
  joints[2] = (Vec2){2.0f, 0.0f};

  lengths[0] = 1.0f;
  lengths[1] = 1.0f;
  lengths[2] = 0.35f;

  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);

  HAL_GPIO_WritePin(LD4_GPIO_Port, LD4_Pin, GPIO_PIN_SET);
  set_servo_angle(0, 90);
  set_servo_angle(1, 0);
  set_servo_angle(2, 0);
  set_servo_angle(3, 0);
  set_servo_angle_smooth(0, 90);
  set_servo_angle_smooth(1, 0);
  set_servo_angle_smooth(2, 0);
  set_servo_angle_smooth(3, 0);

  Vec2 target = {-0.5f, 0.0f};
  Vec2 step={0.00f, 0.01f};
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  //if(target.y==0.5f || target.y==1.5f) step.y=step.y*(-1);
	  //open_efektor();
	  fabrik_solve(target);
	  //close_efektor();

	  printf("FABRIK:\n");
	  for (int i = 0; i < joint_count; i++)
	  {
	      printf("joint %d: (%.3f, %.3f)\n", i, joints[i].x, joints[i].y);
	  }
	  printf("\n");
	  //wyliczam katy
	  float segment_angles[MAX_JOINTS - 1];

	  for (int i = 0; i < joint_count - 1; i++)
	  {
	      segment_angles[i] = compute_angle(joints[i], joints[i+1]);
	      printf("segment %d angle: %.2f\n", i, segment_angles[i]);
	  }

	  float servo_angles[SERVO_COUNT];

	  servo_angles[0] = segment_angles[0]; // absolutny kąt pierwszego segmentu

	  for (int i = 1; i < joint_count - 1; i++)
	  {
	      servo_angles[i] = segment_angles[i] - segment_angles[i-1];
	      // opcjonalnie dopasowanie do zakresu 0-180:
	      if (servo_angles[i] < 0) servo_angles[i] += 360;
	  }
	  //do teraz

	  printf("Servo angles:\n");
	  for (int i = 0; i < joint_count - 1; i++)
	  {
	      printf("servo %d: %.2f°\n", i, servo_angles[i]);
	  }
	  printf("\n");



	  if(!emergency_stop){
		  //set_servo_angle_smooth(2, 180-(servo_angle[2]/180)*180);
		  for(int i=0; i<SERVO_COUNT; i++){
			  set_servo_angle_smooth(i, servo_angles[i]);
		  }
	  }
	  printf("angles:\n0:%d\n1:%d\n2:%d\n3:%d\n\n",servo_angle[0],servo_angle[1],servo_angle[2],servo_angle[3]);

	  //target=vec_add(target, step);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 64;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = TIM2_PRESCALER;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = TIM2_COUNTER_PERIOD;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD4_GPIO_Port, LD4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD4_Pin */
  GPIO_InitStruct.Pin = LD4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD4_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
